
import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var lbl: UILabel!
    
    
    @IBAction func display(_ sender: Any)
    {
        let dif = UserDefaults.standard
        dif.set("100", forKey: "id")
        
    }
    
    @IBAction func create(_ sender: Any)
    {
        let dif = UserDefaults.standard
        let val = dif.value(forKey: "id")
        lbl.text = val as! String?
    }
    override func viewDidLoad() {
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}

